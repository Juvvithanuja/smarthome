# Overview

This is a full-stack Smart Home Dashboard application built with React, Express, TypeScript, and PostgreSQL. The system allows users to manage IoT devices like lights, fans, and sensors through a modern web interface. Users can monitor real-time sensor data, control devices, view analytics, and manage their smart home ecosystem. The application features real-time updates via WebSocket connections and provides comprehensive device management and monitoring capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with React 18 using TypeScript and follows a modern component-based architecture:

- **UI Framework**: Utilizes shadcn/ui components built on Radix UI primitives for consistent, accessible design
- **State Management**: React Query (@tanstack/react-query) handles server state management, caching, and data synchronization
- **Routing**: Wouter provides lightweight client-side routing with protected routes for authentication
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **Form Handling**: React Hook Form with Zod validation for type-safe forms
- **Real-time Updates**: Custom WebSocket hook for live device status updates

## Backend Architecture
The backend follows a RESTful API design with Express.js:

- **Server Framework**: Express.js with TypeScript for type safety
- **Authentication**: Passport.js with local strategy using session-based authentication
- **Session Management**: PostgreSQL session store with express-session
- **Password Security**: Crypto module with scrypt for secure password hashing
- **Real-time Communication**: WebSocket server for pushing device updates to clients
- **API Structure**: Organized route handlers with proper error handling and validation

## Data Storage Solutions
The application uses PostgreSQL with Drizzle ORM for database operations:

- **Database**: PostgreSQL hosted on Neon (serverless PostgreSQL)
- **ORM**: Drizzle ORM provides type-safe database queries and migrations
- **Schema Design**: 
  - Users table for authentication and ownership
  - Devices table for IoT device management with JSON properties for device-specific data
  - Sensor data table for time-series data storage
  - Device usage table for activity tracking and analytics
- **Relationships**: Proper foreign key relationships between users, devices, and their data

## Authentication and Authorization
Session-based authentication system:

- **Strategy**: Local username/password authentication via Passport.js
- **Session Storage**: PostgreSQL-backed session store for scalability
- **Security**: Scrypt password hashing with salt for secure credential storage
- **Authorization**: User-based device ownership model with proper access controls
- **Protected Routes**: Frontend route protection ensuring authenticated access

## External Dependencies

### Core Technologies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe ORM for database operations
- **passport & passport-local**: Authentication middleware and strategy
- **express-session**: Session management middleware
- **connect-pg-simple**: PostgreSQL session store adapter

### Frontend Libraries
- **@tanstack/react-query**: Server state management and caching
- **@hookform/resolvers**: Form validation with Zod integration
- **wouter**: Lightweight React router
- **recharts**: Data visualization for analytics charts
- **date-fns**: Date manipulation utilities

### UI Components
- **@radix-ui/***: Accessible, unstyled UI primitives
- **shadcn/ui**: Pre-built component library built on Radix UI
- **lucide-react**: Icon library
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **vite**: Fast build tool and development server
- **typescript**: Type safety across the entire stack
- **drizzle-kit**: Database migration and schema management
- **@replit/vite-plugin-***: Replit-specific development enhancements