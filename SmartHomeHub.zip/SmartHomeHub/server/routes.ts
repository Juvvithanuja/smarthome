import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertDeviceSchema, insertSensorDataSchema, insertDeviceUsageSchema } from "@shared/schema";
import { z } from "zod";

export function registerRoutes(app: Express): Server {
  // Setup authentication routes
  setupAuth(app);

  // Device routes
  app.get("/api/devices", async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const devices = await storage.getDevicesByOwner(req.user.id);
      res.json(devices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch devices" });
    }
  });

  app.post("/api/devices", async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const deviceData = insertDeviceSchema.parse({
        ...req.body,
        ownerId: req.user.id,
      });
      const device = await storage.createDevice(deviceData);
      res.status(201).json(device);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid device data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create device" });
    }
  });

  app.patch("/api/devices/:id", async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const device = await storage.getDevice(req.params.id);
      if (!device || device.ownerId !== req.user.id) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      const updatedDevice = await storage.updateDevice(req.params.id, req.body);
      
      // Log device usage
      if (req.body.status !== undefined) {
        await storage.addDeviceUsage({
          deviceId: req.params.id,
          action: req.body.status ? 'turned_on' : 'turned_off',
          value: req.body.status.toString(),
        });
      }
      
      // Broadcast device update via WebSocket
      broadcastDeviceUpdate(updatedDevice);
      
      res.json(updatedDevice);
    } catch (error) {
      console.error("Error updating device:", error);
      res.status(500).json({ message: "Failed to update device", error: error instanceof Error ? error.message : String(error) });
    }
  });

  app.delete("/api/devices/:id", async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const device = await storage.getDevice(req.params.id);
      if (!device || device.ownerId !== req.user.id) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      await storage.deleteDevice(req.params.id);
      res.json({ message: "Device deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete device" });
    }
  });

  // Sensor data routes
  app.get("/api/devices/:id/sensor-data", async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const device = await storage.getDevice(req.params.id);
      if (!device || device.ownerId !== req.user.id) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const sensorData = await storage.getSensorDataByDevice(req.params.id, limit);
      res.json(sensorData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sensor data" });
    }
  });

  app.post("/api/devices/:id/sensor-data", async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const device = await storage.getDevice(req.params.id);
      if (!device || device.ownerId !== req.user.id) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      const sensorDataInput = insertSensorDataSchema.parse({
        ...req.body,
        deviceId: req.params.id,
      });
      
      const sensorData = await storage.addSensorData(sensorDataInput);
      
      // Broadcast sensor data via WebSocket
      broadcastSensorData(sensorData);
      
      res.status(201).json(sensorData);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid sensor data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add sensor data" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/device-usage", async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const stats = await storage.getDeviceUsageStats(req.user.id);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch device usage stats" });
    }
  });

  app.get("/api/analytics/sensor-trends/:deviceId", async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const device = await storage.getDevice(req.params.deviceId);
      if (!device || device.ownerId !== req.user.id) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      const days = req.query.days ? parseInt(req.query.days as string) : 7;
      const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
      const endDate = new Date();
      
      const trends = await storage.getSensorDataByDateRange(req.params.deviceId, startDate, endDate);
      res.json(trends);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sensor trends" });
    }
  });

  const httpServer = createServer(app);
  
  // WebSocket setup
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    
    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message);
        console.log('Received WebSocket message:', data);
      } catch (error) {
        console.error('Invalid WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  function broadcastDeviceUpdate(device: any) {
    const message = JSON.stringify({
      type: 'device_update',
      data: device,
    });
    
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  function broadcastSensorData(sensorData: any) {
    const message = JSON.stringify({
      type: 'sensor_data',
      data: sensorData,
    });
    
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  return httpServer;
}
