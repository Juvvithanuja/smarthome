import { 
  users, 
  devices, 
  sensorData, 
  deviceUsage,
  type User, 
  type InsertUser,
  type Device,
  type InsertDevice,
  type SensorData,
  type InsertSensorData,
  type DeviceUsage,
  type InsertDeviceUsage
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, sql } from "drizzle-orm";
import session, { Store } from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Device methods
  getDevicesByOwner(ownerId: string): Promise<Device[]>;
  getDevice(id: string): Promise<Device | undefined>;
  createDevice(device: InsertDevice): Promise<Device>;
  updateDevice(id: string, updates: Partial<Device>): Promise<Device | undefined>;
  deleteDevice(id: string): Promise<boolean>;
  
  // Sensor data methods
  getSensorDataByDevice(deviceId: string, limit?: number): Promise<SensorData[]>;
  addSensorData(data: InsertSensorData): Promise<SensorData>;
  getSensorDataByDateRange(deviceId: string, startDate: Date, endDate: Date): Promise<SensorData[]>;
  
  // Device usage methods
  addDeviceUsage(usage: InsertDeviceUsage): Promise<DeviceUsage>;
  getDeviceUsageByDateRange(deviceId: string, startDate: Date, endDate: Date): Promise<DeviceUsage[]>;
  getDeviceUsageStats(ownerId: string): Promise<any>;
  
  sessionStore: Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getDevicesByOwner(ownerId: string): Promise<Device[]> {
    return db.select().from(devices).where(eq(devices.ownerId, ownerId));
  }

  async getDevice(id: string): Promise<Device | undefined> {
    const [device] = await db.select().from(devices).where(eq(devices.id, id));
    return device;
  }

  async createDevice(device: InsertDevice): Promise<Device> {
    const [newDevice] = await db
      .insert(devices)
      .values(device)
      .returning();
    return newDevice;
  }

  async updateDevice(id: string, updates: Partial<Device>): Promise<Device | undefined> {
    const [updated] = await db
      .update(devices)
      .set(updates)
      .where(eq(devices.id, id))
      .returning();
    return updated;
  }

  async deleteDevice(id: string): Promise<boolean> {
    const result = await db.delete(devices).where(eq(devices.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getSensorDataByDevice(deviceId: string, limit = 100): Promise<SensorData[]> {
    return db
      .select()
      .from(sensorData)
      .where(eq(sensorData.deviceId, deviceId))
      .orderBy(desc(sensorData.timestamp))
      .limit(limit);
  }

  async addSensorData(data: InsertSensorData): Promise<SensorData> {
    const [newData] = await db
      .insert(sensorData)
      .values(data)
      .returning();
    return newData;
  }

  async getSensorDataByDateRange(deviceId: string, startDate: Date, endDate: Date): Promise<SensorData[]> {
    return db
      .select()
      .from(sensorData)
      .where(
        and(
          eq(sensorData.deviceId, deviceId),
          gte(sensorData.timestamp, startDate),
          sql`${sensorData.timestamp} <= ${endDate}`
        )
      )
      .orderBy(sensorData.timestamp);
  }

  async addDeviceUsage(usage: InsertDeviceUsage): Promise<DeviceUsage> {
    const [newUsage] = await db
      .insert(deviceUsage)
      .values(usage)
      .returning();
    return newUsage;
  }

  async getDeviceUsageByDateRange(deviceId: string, startDate: Date, endDate: Date): Promise<DeviceUsage[]> {
    return db
      .select()
      .from(deviceUsage)
      .where(
        and(
          eq(deviceUsage.deviceId, deviceId),
          gte(deviceUsage.timestamp, startDate),
          sql`${deviceUsage.timestamp} <= ${endDate}`
        )
      )
      .orderBy(deviceUsage.timestamp);
  }

  async getDeviceUsageStats(ownerId: string): Promise<any> {
    // Get device usage statistics for the last 24 hours
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    const stats = await db
      .select({
        deviceId: deviceUsage.deviceId,
        deviceName: devices.name,
        actionCount: sql<number>`count(*)`,
      })
      .from(deviceUsage)
      .leftJoin(devices, eq(deviceUsage.deviceId, devices.id))
      .where(
        and(
          eq(devices.ownerId, ownerId),
          gte(deviceUsage.timestamp, oneDayAgo)
        )
      )
      .groupBy(deviceUsage.deviceId, devices.name);

    return stats;
  }
}

export const storage = new DatabaseStorage();
