import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, boolean, integer, timestamp, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const devices = pgTable("devices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'light', 'fan', 'sensor'
  location: text("location").notNull(),
  deviceId: text("device_id").notNull().unique(),
  status: boolean("status").default(false), // on/off for controllable devices
  isOnline: boolean("is_online").default(true),
  properties: jsonb("properties"), // for device-specific properties like brightness, speed, etc.
  ownerId: varchar("owner_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sensorData = pgTable("sensor_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  deviceId: varchar("device_id").references(() => devices.id),
  value: real("value").notNull(),
  unit: text("unit").notNull(), // °C, %, etc.
  timestamp: timestamp("timestamp").defaultNow(),
});

export const deviceUsage = pgTable("device_usage", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  deviceId: varchar("device_id").references(() => devices.id),
  action: text("action").notNull(), // 'turned_on', 'turned_off', 'brightness_changed'
  value: text("value"), // for storing action values
  timestamp: timestamp("timestamp").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  devices: many(devices),
}));

export const devicesRelations = relations(devices, ({ one, many }) => ({
  owner: one(users, {
    fields: [devices.ownerId],
    references: [users.id],
  }),
  sensorData: many(sensorData),
  usage: many(deviceUsage),
}));

export const sensorDataRelations = relations(sensorData, ({ one }) => ({
  device: one(devices, {
    fields: [sensorData.deviceId],
    references: [devices.id],
  }),
}));

export const deviceUsageRelations = relations(deviceUsage, ({ one }) => ({
  device: one(devices, {
    fields: [deviceUsage.deviceId],
    references: [devices.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  name: true,
});

export const insertDeviceSchema = createInsertSchema(devices).omit({
  id: true,
  createdAt: true,
});

export const insertSensorDataSchema = createInsertSchema(sensorData).omit({
  id: true,
  timestamp: true,
});

export const insertDeviceUsageSchema = createInsertSchema(deviceUsage).omit({
  id: true,
  timestamp: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;
export type Device = typeof devices.$inferSelect;
export type InsertSensorData = z.infer<typeof insertSensorDataSchema>;
export type SensorData = typeof sensorData.$inferSelect;
export type InsertDeviceUsage = z.infer<typeof insertDeviceUsageSchema>;
export type DeviceUsage = typeof deviceUsage.$inferSelect;
