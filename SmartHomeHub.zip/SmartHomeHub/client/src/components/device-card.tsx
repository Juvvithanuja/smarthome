import { useMutation } from "@tanstack/react-query";
import { Device } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Lightbulb, Fan, Thermometer, Droplets, Power } from "lucide-react";

interface DeviceCardProps {
  device: Device;
  "data-testid"?: string;
}

export default function DeviceCard({ device, "data-testid": testId }: DeviceCardProps) {
  const { toast } = useToast();

  const toggleDeviceMutation = useMutation({
    mutationFn: async (newStatus: boolean) => {
      const res = await apiRequest("PATCH", `/api/devices/${device.id}`, {
        status: newStatus,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to toggle device: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const getDeviceIcon = () => {
    switch (device.type) {
      case 'light':
        return <Lightbulb className="h-6 w-6" />;
      case 'fan':
        return <Fan className="h-6 w-6" />;
      case 'sensor':
        if (device.name.toLowerCase().includes('temperature')) {
          return <Thermometer className="h-6 w-6" />;
        } else if (device.name.toLowerCase().includes('humidity')) {
          return <Droplets className="h-6 w-6" />;
        }
        return <Power className="h-6 w-6" />;
      default:
        return <Power className="h-6 w-6" />;
    }
  };

  const getIconColor = () => {
    if (!device.isOnline) return "text-muted-foreground";
    
    switch (device.type) {
      case 'light':
        return device.status ? "text-accent" : "text-muted-foreground";
      case 'fan':
        return device.status ? "text-secondary" : "text-muted-foreground";
      case 'sensor':
        return "text-warning";
      default:
        return "text-primary";
    }
  };

  const getBackgroundColor = () => {
    if (!device.isOnline) return "bg-muted/10";
    
    switch (device.type) {
      case 'light':
        return "bg-accent/10";
      case 'fan':
        return "bg-secondary/10";
      case 'sensor':
        return "bg-warning/10";
      default:
        return "bg-primary/10";
    }
  };

  const handleToggle = (checked: boolean) => {
    if (device.type === 'sensor') return; // Sensors cannot be toggled
    toggleDeviceMutation.mutate(checked);
  };

  const isControllable = device.type !== 'sensor';
  const props = device.properties as Record<string, any> | undefined;
  const displayValue = props?.value;
  const displayUnit = props?.unit || '';

  return (
    <Card 
      className="device-card transition-all duration-200 hover:shadow-lg hover:-translate-y-1" 
      data-testid={testId}
    >
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`w-12 h-12 ${getBackgroundColor()} rounded-lg flex items-center justify-center`}>
              <div className={getIconColor()}>
                {getDeviceIcon()}
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-card-foreground">{device.name}</h3>
              <p className="text-sm text-muted-foreground">{device.location}</p>
            </div>
          </div>
          
          {isControllable && (
            <Switch
              checked={!!device.status}
              onCheckedChange={handleToggle}
              disabled={!device.isOnline || toggleDeviceMutation.isPending}
              data-testid={`switch-${device.id}`}
            />
          )}
          
          {!isControllable && displayValue && (
            <div className="text-right">
              <div className="text-lg font-bold text-card-foreground">
                {displayValue}{displayUnit}
              </div>
              <div className="text-xs text-success">Normal</div>
            </div>
          )}
        </div>
        
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Status</span>
          <Badge 
            variant={device.isOnline ? "default" : "secondary"}
            className={device.isOnline ? "bg-success text-white" : ""}
          >
            {device.isOnline ? "Online" : "Offline"}
          </Badge>
        </div>
        
        {device.type === 'light' && props?.brightness && (
          <div className="flex items-center justify-between text-sm mt-2">
            <span className="text-muted-foreground">Brightness</span>
            <span className="text-accent font-medium">{props.brightness}%</span>
          </div>
        )}
        
        {device.type === 'fan' && props?.speed && (
          <div className="flex items-center justify-between text-sm mt-2">
            <span className="text-muted-foreground">Speed</span>
            <span className="text-secondary font-medium">{props.speed}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
