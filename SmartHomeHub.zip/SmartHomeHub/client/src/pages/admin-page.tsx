import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Device, insertDeviceSchema } from "@shared/schema";
import Sidebar from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2 } from "lucide-react";
import { z } from "zod";

const deviceFormSchema = insertDeviceSchema.omit({ ownerId: true });
type DeviceFormData = z.infer<typeof deviceFormSchema>;

export default function AdminPage() {
  const [isEditing, setIsEditing] = useState(false);
  const [editingDevice, setEditingDevice] = useState<Device | null>(null);
  const { toast } = useToast();

  const { data: devices = [], isLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const form = useForm<DeviceFormData>({
    resolver: zodResolver(deviceFormSchema),
    defaultValues: {
      name: "",
      type: "",
      location: "",
      deviceId: "",
      status: false,
      isOnline: true,
      properties: {},
    },
  });

  const createDeviceMutation = useMutation({
    mutationFn: async (data: DeviceFormData) => {
      const res = await apiRequest("POST", "/api/devices", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      form.reset();
      setIsEditing(false);
      toast({
        title: "Success",
        description: "Device created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateDeviceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Device> }) => {
      const res = await apiRequest("PATCH", `/api/devices/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      form.reset();
      setIsEditing(false);
      setEditingDevice(null);
      toast({
        title: "Success",
        description: "Device updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteDeviceMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/devices/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      toast({
        title: "Success",
        description: "Device deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: DeviceFormData) => {
    if (editingDevice) {
      updateDeviceMutation.mutate({ id: editingDevice.id, data });
    } else {
      createDeviceMutation.mutate(data);
    }
  };

  const handleEdit = (device: Device) => {
    setEditingDevice(device);
    setIsEditing(true);
    form.reset({
      name: device.name,
      type: device.type,
      location: device.location,
      deviceId: device.deviceId,
      status: device.status,
      isOnline: device.isOnline,
      properties: device.properties || {},
    });
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this device?")) {
      deleteDeviceMutation.mutate(id);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditingDevice(null);
    form.reset();
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto p-6">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-foreground">Admin Panel</h2>
          <p className="text-muted-foreground">Manage IoT devices and system settings</p>
        </div>
        
        {/* Device Management Table */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Device Management</CardTitle>
              <Button 
                onClick={() => setIsEditing(true)}
                data-testid="button-add-device"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Device
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">Loading devices...</div>
            ) : (
              <Table data-testid="table-devices">
                <TableHeader>
                  <TableRow>
                    <TableHead>Device Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {devices.map((device) => (
                    <TableRow key={device.id} data-testid={`row-device-${device.id}`}>
                      <TableCell className="font-medium">{device.name}</TableCell>
                      <TableCell className="capitalize">{device.type}</TableCell>
                      <TableCell>{device.location}</TableCell>
                      <TableCell>
                        <Badge 
                          variant={device.isOnline ? "default" : "secondary"}
                          className={device.isOnline ? "bg-success text-white" : ""}
                        >
                          {device.isOnline ? "Online" : "Offline"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(device)}
                            data-testid={`button-edit-${device.id}`}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(device.id)}
                            className="text-destructive hover:text-destructive"
                            data-testid={`button-delete-${device.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {devices.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        No devices found. Add your first device to get started.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
        
        {/* Add/Edit Device Form */}
        {isEditing && (
          <Card data-testid="form-device">
            <CardHeader>
              <CardTitle>
                {editingDevice ? "Edit Device" : "Add New Device"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Device Name</Label>
                  <Input
                    id="name"
                    {...form.register("name")}
                    placeholder="Living Room Light"
                    data-testid="input-device-name"
                  />
                  {form.formState.errors.name && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.name.message}
                    </p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="type">Device Type</Label>
                  <Select 
                    value={form.watch("type")} 
                    onValueChange={(value) => form.setValue("type", value)}
                  >
                    <SelectTrigger data-testid="select-device-type">
                      <SelectValue placeholder="Select device type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Smart Light</SelectItem>
                      <SelectItem value="fan">Smart Fan</SelectItem>
                      <SelectItem value="sensor">Sensor</SelectItem>
                      <SelectItem value="switch">Smart Switch</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.type && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.type.message}
                    </p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    {...form.register("location")}
                    placeholder="Living Room"
                    data-testid="input-device-location"
                  />
                  {form.formState.errors.location && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.location.message}
                    </p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="deviceId">Device ID</Label>
                  <Input
                    id="deviceId"
                    {...form.register("deviceId")}
                    placeholder="ESP32_001"
                    data-testid="input-device-id"
                  />
                  {form.formState.errors.deviceId && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.deviceId.message}
                    </p>
                  )}
                </div>
                
                <div className="md:col-span-2 flex space-x-4">
                  <Button 
                    type="submit" 
                    disabled={createDeviceMutation.isPending || updateDeviceMutation.isPending}
                    data-testid="button-save-device"
                  >
                    {editingDevice ? "Update Device" : "Save Device"}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={handleCancel}
                    data-testid="button-cancel-device"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
