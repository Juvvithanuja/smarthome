import { useQuery } from "@tanstack/react-query";
import { Device, SensorData } from "@shared/schema";
import Sidebar from "@/components/sidebar";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function AnalyticsPage() {
  const { data: devices = [] } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const { data: deviceUsageStats = [] } = useQuery({
    queryKey: ["/api/analytics/device-usage"],
  });

  // Get sensor devices for trend analysis
  const sensorDevices = devices.filter(d => d.type === 'sensor');
  const tempSensor = sensorDevices.find(d => d.name.toLowerCase().includes('temperature'));
  const humiditySensor = sensorDevices.find(d => d.name.toLowerCase().includes('humidity'));

  const { data: tempTrends = [] } = useQuery<SensorData[]>({
    queryKey: ["/api/analytics/sensor-trends", tempSensor?.id],
    enabled: !!tempSensor,
  });

  const { data: humidityTrends = [] } = useQuery<SensorData[]>({
    queryKey: ["/api/analytics/sensor-trends", humiditySensor?.id],
    enabled: !!humiditySensor,
  });

  // Mock energy usage data for demonstration
  const energyData = Array.from({ length: 24 }, (_, i) => ({
    hour: `${i}:00`,
    usage: Math.random() * 3 + 1,
  }));

  // Process device activity data
  const deviceActivityData = devices.map(device => ({
    name: device.name,
    value: device.status ? 1 : 0,
    fill: device.status ? '#10B981' : '#6B7280',
  }));

  // Process temperature trends
  const tempChartData = tempTrends.filter(data => data.timestamp).map(data => ({
    time: new Date(data.timestamp as Date).toLocaleDateString(),
    temperature: data.value,
  }));

  // Process humidity trends  
  const humidityChartData = humidityTrends.filter(data => data.timestamp).map(data => ({
    time: new Date(data.timestamp as Date).toLocaleDateString(),
    humidity: data.value,
  }));

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto p-6">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-foreground">Analytics</h2>
          <p className="text-muted-foreground">Device usage patterns and sensor trends</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Energy Usage Chart */}
          <Card data-testid="chart-energy-usage">
            <CardHeader>
              <CardTitle>Energy Usage (24h)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={energyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="hour" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="usage" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    name="Energy (kW)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          
          {/* Device Activity Chart */}
          <Card data-testid="chart-device-activity">
            <CardHeader>
              <CardTitle>Device Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={deviceActivityData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value ? 'ON' : 'OFF'}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {deviceActivityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Temperature Trends */}
          <Card data-testid="chart-temperature-trends">
            <CardHeader>
              <CardTitle>Temperature Trends (7 days)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                {tempChartData.length > 0 ? (
                  <AreaChart data={tempChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area
                      type="monotone"
                      dataKey="temperature"
                      stroke="hsl(var(--warning))"
                      fill="hsl(var(--warning))"
                      fillOpacity={0.3}
                      name="Temperature (°C)"
                    />
                  </AreaChart>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    <div className="text-center">
                      <p>No temperature data available</p>
                      <p className="text-sm">Add a temperature sensor to see trends</p>
                    </div>
                  </div>
                )}
              </ResponsiveContainer>
            </CardContent>
          </Card>
          
          {/* Humidity Trends */}
          <Card data-testid="chart-humidity-trends">
            <CardHeader>
              <CardTitle>Humidity Levels (7 days)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                {humidityChartData.length > 0 ? (
                  <LineChart data={humidityChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="humidity"
                      stroke="hsl(var(--secondary))"
                      strokeWidth={2}
                      name="Humidity (%)"
                    />
                  </LineChart>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    <div className="text-center">
                      <p>No humidity data available</p>
                      <p className="text-sm">Add a humidity sensor to see trends</p>
                    </div>
                  </div>
                )}
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
