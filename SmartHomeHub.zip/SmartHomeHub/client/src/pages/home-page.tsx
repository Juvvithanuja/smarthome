import { useQuery } from "@tanstack/react-query";
import { Device } from "@shared/schema";
import Sidebar from "@/components/sidebar";
import DeviceCard from "@/components/device-card";
import StatsCard from "@/components/stats-card";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect, useState } from "react";
import { Power, Zap, Thermometer, Droplets } from "lucide-react";

export default function HomePage() {
  const [stats, setStats] = useState({
    activeDevices: 0,
    energyUsage: "0 kW",
    temperature: "0°C",
    humidity: "0%",
  });

  const { data: devices = [], isLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const { lastMessage } = useWebSocket();

  useEffect(() => {
    if (devices.length > 0) {
      const activeCount = devices.filter(device => device.status && device.isOnline).length;
      
      // Find temperature and humidity sensors
      const tempSensor = devices.find(d => d.type === 'sensor' && d.name.toLowerCase().includes('temperature'));
      const humiditySensor = devices.find(d => d.type === 'sensor' && d.name.toLowerCase().includes('humidity'));
      
      const tempValue = (tempSensor?.properties as Record<string, any> | undefined)?.value as number | undefined;
      const humidityValue = (humiditySensor?.properties as Record<string, any> | undefined)?.value as number | undefined;
      
      setStats({
        activeDevices: activeCount,
        energyUsage: `${(activeCount * 0.3).toFixed(1)} kW`,
        temperature: tempValue != null ? `${tempValue}°C` : "22°C",
        humidity: humidityValue != null ? `${humidityValue}%` : "65%",
      });
    }
  }, [devices]);

  if (isLoading) {
    return (
      <div className="flex h-screen">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-card p-6 rounded-lg border animate-pulse">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-6 bg-muted rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto p-6">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-foreground">Dashboard</h2>
          <p className="text-muted-foreground">Monitor and control your connected devices</p>
        </div>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Active Devices"
            value={stats.activeDevices.toString()}
            icon={Power}
            color="success"
            data-testid="stat-active-devices"
          />
          <StatsCard
            title="Energy Usage"
            value={stats.energyUsage}
            icon={Zap}
            color="warning"
            data-testid="stat-energy-usage"
          />
          <StatsCard
            title="Temperature"
            value={stats.temperature}
            icon={Thermometer}
            color="accent"
            data-testid="stat-temperature"
          />
          <StatsCard
            title="Humidity"
            value={stats.humidity}
            icon={Droplets}
            color="secondary"
            data-testid="stat-humidity"
          />
        </div>
        
        {/* Device Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {devices.map((device) => (
            <DeviceCard 
              key={device.id} 
              device={device} 
              data-testid={`device-card-${device.id}`}
            />
          ))}
          
          {devices.length === 0 && (
            <div className="col-span-full text-center py-12">
              <p className="text-muted-foreground text-lg">No devices found</p>
              <p className="text-muted-foreground">Add devices from the Admin panel to get started</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
